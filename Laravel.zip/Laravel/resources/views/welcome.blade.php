<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="Hello Word" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    /** Para criar um html do 0 é necessario colocar o ponto de esclamação "!" e apertar o tab 
    
</body>
</html>